# Hey Player: a hands-free Jellyfin remote built from spare parts

*A build log of turning a laptop, a wake word, Jellyfin, mpv, voxtype, Vosk, and an AI agent into one sentence you can say from across the room.*

> **TL;DR** — Saying **“Hey Player, play dark techno”** starts local mpv playback from a Jellyfin server, and a spoken confirmation comes back in about **2.6 seconds**. Nothing needs to be typed or clicked; no keys, tokens, or passwords are stored in this post. The screen later runs a custom Matrix-style screensaver that never locks or suspends the machine.

---

## Table of contents

1. [What we wanted](#1-what-we-wanted)
2. [Architecture](#2-architecture)
3. [Jellyfin and the MCP patch](#3-jellyfin-and-the-mcp-patch)
4. [Local playback with mpv](#4-local-playback-with-mpv)
5. [The wake word and dictation pipeline](#5-the-wake-word-and-dictation-pipeline)
6. [Fast spoken confirmations](#6-fast-spoken-confirmations)
7. [Getting the command into the agent](#7-getting-the-command-into-the-agent)
8. [Screen, lid, and power behavior](#8-screen-lid-and-power-behavior)
9. [The custom screensaver](#9-the-custom-screensaver)
10. [File and command reference](#10-file-and-command-reference)
11. [Gotchas and lessons learned](#11-gotchas-and-lessons-learned)
12. [Links and credits](#12-links-and-credits)

---

## 1. What we wanted

The target behavior was deliberately simple:

- Music plays **locally** from the laptop's own mpv process, fed by a Jellyfin server on the LAN.
- The only input is a spoken command beginning with **“Hey Player”** — a true hands-free wake word, not a hotkey.
- The agent in a dedicated OpenChamber voice session **executes** the command; it does not speak.
- A short confirmation is spoken immediately, in parallel with execution.
- Defaults: volume **100**, audio-only, no shuffle or loop unless explicitly requested.
- The laptop must not lock, blank-and-suspend, or do anything when the lid closes.
- Secrets stay in private env files and the OS secret flow — never in config files pasted into chat.

This post is accompanied by a self-contained archive: every working script, the relevant config snippets, the MCP patch, the diagram, and the screensaver preview are included under [`scripts/`](scripts/), [`config/`](config/), [`patches/`](patches/), and [`assets/`](assets/). Sensitive values were redacted on copy; env files themselves are intentionally absent.

---

## 2. Architecture

![Voice control architecture](assets/architecture.svg)

The flow has two branches after the transcript exists:

1. **Execution branch** — inject the transcript into the voice session, let the agent resolve aliases and call the local Jellyfin/mpv helpers.
2. **Confirmation branch** — map the transcript to one of a small set of canonical sentences and speak it from a cached TTS file immediately, without waiting for the agent.

That split is the reason the spoken feedback feels instant even though an LLM is in the loop.

---

## 3. Jellyfin and the MCP patch

The server is `Jellyfin` (Jellyfin 12.4.0) at `http://jellyfin.lan:8096/`, with a local user account. Credentials live in `~/.config/openchamber/jellyfin/.env` and are read at runtime.

### Two auth surprises

> **Lesson:** a trailing slash in `JELLYFIN_URL` produced API `404`s. Normalize with `rstrip("/")` before building any URL.

> **Lesson:** this server rejects `X-Emby-Token` with `401`. It accepts `Authorization: MediaBrowser Token="<api-key>"`.

The second one required patching the cloned `sandraschi/jellyfin-mcp` checkout in two places — the HTTP service and the websocket service. The exact diff is preserved in [`patches/jellyfin-mcp-auth.patch`](patches/jellyfin-mcp-auth.patch):

```python
headers={
    "Authorization": (
        f'MediaBrowser Token="{self.api_key}", '
        'Client="JellyfinMCP", Device="OpenCode", '
        'DeviceId="opencode-jellyfin-mcp", Version="1.0"'
    )
}
```

The MCP is registered in `~/.config/opencode/opencode.jsonc` and launched through [`scripts/jellyfin-mcp-local`](scripts/jellyfin-mcp-local), which sources the private env file and runs `uv run jellyfin-mcp --stdio`. Connection and tool availability were verified against the live server.

### One more library quirk

The library contains **no `Audio` items** — the music lives in `MusicVideo` items. The resolver therefore accepts both `Audio` and `MusicVideo`, and the working stream URL form is:

```text
http://jellyfin.lan:8096/Videos/{id}/stream?Static=true
```

Album/artist/playlist/folder IDs are expanded into their playable children before playback.

---

## 4. Local playback with mpv

[`scripts/jellyfin-play-local`](scripts/jellyfin-play-local) resolves search text, item IDs, albums, playlists, or folders through the Jellyfin API and launches mpv with the resulting static stream URLs.

Notable defaults and flags:

| Flag | Behavior |
|---|---|
| *(default)* | volume **100**, `--no-video`, no shuffle, no loop |
| `--video` | opt in to showing video for `MusicVideo` items |
| `--volume N` | initial volume |
| `--shuffle` | randomize resolved items |
| `--loop` | `--loop-playlist=inf` |
| `--pause`, `--ao`, `--limit`, `--dry-run` | start paused, choose audio output, cap results, resolve without playing |

mpv is controlled over a JSON IPC socket at `/tmp/opencode-jellyfin-mpv.sock` through [`scripts/jellyfin-mpv-control`](scripts/jellyfin-mpv-control):

```bash
jellyfin-mpv-control <pause|play|toggle|stop|next|prev|volume N|seek N|status|quit>
```

Audio comes out through PipeWire on this machine. Playback start, pause/resume, track skipping, volume changes, and stop were all verified end to end.

### Alias table used by the agent

| Spoken phrase | Target library | Item ID |
|---|---|---|
| dark techno, dark club, techno | `LF Dark Club Videos` | `<item-id>` |
| epic, cinematic | `LF Epics Videos` | `<item-id>` |
| soft, calm, relax | `LF Soft Videos` | `<item-id>` |
| synth, synthwave | `LF Synth Videos` | `<item-id>` |

---

## 5. The wake word and dictation pipeline

[`scripts/hey-player-listener`](scripts/hey-player-listener) is a long-running user service. It captures 16 kHz mono audio from PipeWire with `pw-record` in 125 ms chunks (4,000 bytes) and feeds a Vosk grammar recognizer using the small English US model.

- Wake variants: `hey player`, `hay player`, `hey players`, `hey play er`.
- **Partial-result detection** triggers on a prefix like `hey play`, which is what makes the response feel fast.
- After a wake: 8-second cooldown, 6-second recording window, 15-second transcript timeout.
- Dictation is handled by **voxtype 1.3.2** with the `base.en` Whisper model. Its hotkey is disabled; the listener triggers `voxtype record start/stop` externally and reads the transcript from a file (config in [`config/voxtype-config.toml`](config/voxtype-config.toml)).
- Relevant timing knobs: `external_trigger_silence_timeout_secs = 1.5` and `external_trigger_speech_threshold_dbfs = -12.0`.

The listener itself never executes playback. It only transcribes, speaks a confirmation, and injects the text.

---

## 6. Fast spoken confirmations

There used to be a slower design where the agent spoke its own reply. That was replaced:

> **New contract:** the wake listener speaks a canonical cached confirmation as soon as a transcript exists, in parallel with injection. The agent only performs the action and replies in chat.

[`scripts/hey-player-say`](scripts/hey-player-say) calls OpenChamber's `/api/dictation/tts/speak` endpoint with the `kokoro-en-v0_19` model, then plays the returned audio with `pw-play`.

- Cache lives under `~/.cache/hey-player/tts`; the cache key includes the text, speaker, and speed, so common confirmations are prewarmed.
- A **15-second duplicate-suppression window** stops a stale agent-side TTS call from repeating a confirmation.
- `espeak` and MBROLA remain installed but are unused.

Canonical mapping examples:

| Heard | Spoken confirmation |
|---|---|
| pause / stop | “Pausing the music.” / “Stopping the music.” |
| next / skip | “Playing the next track.” |
| previous / back | “Playing the previous track.” |
| dark techno | “Playing dark techno music from Jellyfin.” |
| volume 40 | “Setting volume to 40 percent.” |

**Measured fast path**

| Event | Time after wake |
|---|---:|
| Confirmation starts | **2.62 s** |
| Command injected | **2.89 s** |

---

## 7. Getting the command into the agent

[`scripts/hey-player-inject`](scripts/hey-player-inject) posts to the local OpenChamber agent-tool endpoint with a payload shaped like this (session ID shown as a placeholder — the real one is private):

```json
{
  "input": {
    "action": "session.send",
    "sessionId": "ses_REPLACE_WITH_YOUR_SESSION_ID",
    "prompt": "Hey Player: play dark techno"
  },
  "sessionID": "ses_REPLACE_WITH_YOUR_SESSION_ID",
  "callID": "hey-player-<timestamp>",
  "tool": "openchamber"
}
```

The endpoint and token live in `~/.config/hey-player/agent-tool.env`; a placeholder copy of the session ID is in [`config/session-id.example`](config/session-id.example).

> **Lesson:** `opencode run` cannot be used for injection here — it fails with `provider.free-limit` / “Free usage limit reached”. The OpenChamber session tool works and is what the listener calls.

A manual fallback exists: `Super+Alt+V` runs [`scripts/hey-player-manual`](scripts/hey-player-manual), which records one command and injects it the same way.

---

## 8. Screen, lid, and power behavior

The original setup used GNOME's built-in screen shield with a 10-minute blank, no lock, and no password on wake — no `xscreensaver` installed. Then we changed the model: **blanking should not suspend, and GNOME has no real screensaver**, so we wrote our own.

Final settings:

| Setting | Value |
|---|---|
| `org.gnome.desktop.session idle-delay` | `0` (GNOME never blanks) |
| `org.gnome.desktop.screensaver lock-enabled` | `false` |
| `org.gnome.desktop.screensaver ubuntu-lock-on-suspend` | `false` |
| `sleep-inactive-ac-type` | `'nothing'` |
| `sleep-inactive-battery-type` | `'nothing'` |
| `HandleLidSwitch`, `HandleLidSwitchExternalPower`, `HandleLidSwitchDocked` | `ignore` (persistent drop-in) |

The lid drop-in is preserved in [`config/logind-lid-ignore.conf`](config/logind-lid-ignore.conf). In practice: closing the lid does nothing on AC, battery, docked, or any other state; idle never suspends, so the microphone listener keeps running unattended. The trade-off is battery drain if the machine is left on battery.

---

## 9. The custom screensaver

[`scripts/hey-player-screensaver`](scripts/hey-player-screensaver) is a small GTK3 Python program:

- Uses GNOME's `org.gnome.Mutter.IdleMonitor` D-Bus API to read idle time.
- After 10 minutes, maps a fullscreen, undecorated window with a blank cursor.
- A Cairo `DrawingArea` renders green/cyan falling katakana glyphs at about 30 fps.
- Any key, click, pointer motion, or user-active transition hides it; a 2-second cooldown prevents an immediate re-show if Mutter has not reset idle time yet.
- Animation timers stop while hidden.
- Testing hooks: `--demo` (show now, exit on activity) and `--idle-ms=N` (short threshold).
- Runs under [`config/hey-player-screensaver.service`](config/hey-player-screensaver.service), enabled at login.

![Matrix screensaver preview](assets/screensaver-preview.png)

> **Lesson:** GTK's `draw` signal needs PyGObject's foreign-cairo bridge. Installing `python3-gi-cairo` and calling `gi.require_foreign("cairo")` fixed the `Couldn't find foreign struct converter for 'cairo.Context'` errors.

> **Lesson:** GNOME Shell's screenshot D-Bus API denied access from the tool shell, and `wtype` reported “Compositor does not support the virtual keyboard protocol.” The show/hide paths were therefore verified by driving the callbacks directly and by rendering a frame to a PNG.

---

## 10. File and command reference

All of these are copied into this directory under [`scripts/`](scripts/) and [`config/`](config/). The live paths are:

| Path | Purpose |
|---|---|
| `~/.local/bin/jellyfin-play-local` | Resolve Jellyfin items and launch mpv |
| `~/.local/bin/jellyfin-mpv-control` | mpv JSON IPC helper |
| `~/.local/bin/jellyfin-mcp-local` | Launch the patched Jellyfin MCP |
| `~/.local/bin/hey-player-listener` | Wake detection, transcription, parallel confirm/inject |
| `~/.local/bin/hey-player-say` | Cached Kokoro TTS with duplicate suppression |
| `~/.local/bin/hey-player-inject` | Send a command into the voice session |
| `~/.local/bin/hey-player-manual` | Shortcut fallback |
| `~/.local/bin/hey-player-screensaver` | Custom Matrix screensaver |
| `~/.config/voxtype/config.toml` | External-trigger dictation config |
| `~/.config/systemd/user/hey-player-listener.service` | Wake listener service |
| `~/.config/systemd/user/hey-player-screensaver.service` | Screensaver service |
| `/etc/systemd/logind.conf.d/99-hey-player-lid.conf` | Lid behavior override |
| `~/.local/share/jellyfin-mcp` | Patched MCP checkout |
| `~/.cache/hey-player/tts` | Cached confirmation audio |

Handy checks:

```bash
systemctl --user status hey-player-listener.service hey-player-screensaver.service
gsettings get org.gnome.desktop.session idle-delay
gsettings get org.gnome.settings-daemon.plugins.power sleep-inactive-battery-type
grep '^HandleLidSwitch' /etc/systemd/logind.conf.d/99-hey-player-lid.conf
hey-player-screensaver --demo
hey-player-screensaver --idle-ms=10000
```

---

## 11. Gotchas and lessons learned

1. **Jellyfin URL normalization** — trailing slash caused `404`.
2. **Auth header** — `X-Emby-Token` gave `401`; `MediaBrowser Token="..."` worked.
3. **Library content type** — no `Audio` items; play `MusicVideo` with `?Static=true`.
4. **mpv header parsing** — `--http-header-fields` splits on commas, so the mpv auth header must stay minimal.
5. **Agent feedback loop** — let the listener speak; asking the agent to speak too produced duplicates, hence the 15-second guard.
6. **No `opencode run`** — the free usage limit blocks it; use the session tool.
7. **Idle race** — hiding the screensaver and immediately re-showing needed the 2-second guard.
8. **Wayland testing limits** — screenshot D-Bus and virtual keyboard injection are restricted; test by driving callbacks and rendering frames instead.
9. **Secrets hygiene** — sudo, Jellyfin API keys, and OpenChamber tokens are entered through private secret cards or read from private env files. No secret values appear in this post or its copies.

---

## 12. Links and credits

| Project | Link |
|---|---|
| Jellyfin | <https://jellyfin.org/> |
| jellyfin-mcp | <https://github.com/sandraschi/jellyfin-mcp> |
| voxtype | <https://github.com/peteonrails/voxtype> |
| Vosk | <https://alphacephei.com/vosk/> · <https://alphacephei.com/vosk/models> |
| mpv JSON IPC | <https://mpv.io/manual/master/#json-ipc> |
| PipeWire | <https://pipewire.org/> |
| OpenChamber | <https://docs.openchamber.dev/> · <https://github.com/openchamber/openchamber> |
| OpenCode | <https://opencode.ai/> |
| Kokoro TTS | <https://github.com/hexgrad/kokoro> |
| systemd logind.conf | <https://www.freedesktop.org/software/systemd/man/latest/logind.conf.html> |

---

*Built and verified on a GNOME/Wayland laptop, November 2026. Working copies of every script and config used are in this folder; secret-bearing env files are deliberately not included.*
